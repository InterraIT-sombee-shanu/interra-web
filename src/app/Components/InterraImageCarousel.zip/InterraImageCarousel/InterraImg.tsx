import React from 'react';
import Slider from './Slider';
import slides from './ImgData';

export default function InterraImg() {
  return (
    <Slider slides={ slides } />
  );
}




